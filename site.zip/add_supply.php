<?php
session_start();
require_once 'db.php';

// Проверка авторизации
if (!isset($_SESSION['user'])) {
    header("Location: login.html");
    exit();
}

// Получаем данные из формы
$user_id = $_SESSION['user']['id'];
$product_id = intval($_POST['product_id']);
$quantity = intval($_POST['quantity']);
$date = date("Y-m-d H:i:s");

// Добавление поставки
$stmt = $conn->prepare("INSERT INTO supplies (product_id, user_id, quantity, supply_date) VALUES (?, ?, ?, ?)");
$stmt->bind_param("iiis", $product_id, $user_id, $quantity, $date);
$stmt->execute();
// после добавления поставки
$conn->query("INSERT INTO logs (user_id, action) VALUES ($user_id, 'Добавлена поставка товара ID $product_id на $quantity шт.')");

// Обновление остатков товара
$conn->query("UPDATE products SET quantity = quantity + $quantity WHERE id = $product_id");

// Перенаправление назад
header("Location: " . ($_SESSION['user']['role'] === 'admin' ? "dashboard_admin.php" : "dashboard_staff.php"));
exit();
?>
