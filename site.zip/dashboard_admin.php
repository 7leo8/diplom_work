<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Админ-панель | OptoSklad54</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <span class="navbar-brand">OptoSklad54 | Администратор</span>
    <div class="d-flex">
      <a href="log.php" class="btn btn-outline-light">Выход</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <h4>Здравствуйте, <?= $_SESSION['user']['username']; ?>!</h4>

  <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 mt-4">

    <div class="col">
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">📦 Управление товарами</h5>
          <p class="card-text">Просмотр, добавление, редактирование и удаление товаров.</p>
          <a href="products.php" class="btn btn-primary w-100">Перейти</a>
        </div>
      </div>
    </div>

    <div class="col">
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">➕ Управление поставками</h5>
          <p class="card-text">Полный список поставок, управление записями.</p>
          <a href="supply_history.php" class="btn btn-primary w-100">Перейти</a>
        </div>
      </div>
    </div>

    <div class="col">
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">👥 Пользователи</h5>
          <p class="card-text">Просмотр и удаление сотрудников и администраторов.</p>
          <a href="users.php" class="btn btn-primary w-100">Перейти</a>
        </div>
      </div>
    </div>

    <div class="col">
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">📊 Отчёты</h5>
          <p class="card-text">Сводная информация по поставкам с фильтрацией.</p>
          <a href="reports.php" class="btn btn-primary w-100">Перейти</a>
        </div>
      </div>
    </div>

    <div class="col">
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">🧾 Журнал действий</h5>
          <p class="card-text">История изменений и действий пользователей.</p>
          <a href="logs.php" class="btn btn-primary w-100">Перейти</a>
        </div>
      </div>
    </div>

  </div>
</div>
</body>
</html>
