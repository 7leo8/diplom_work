<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'staff') {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Панель сотрудника | OptoSklad54</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <span class="navbar-brand">OptoSklad54</span>
    <div class="d-flex">
      <!-- ЭТА ЧАСТЬ: Просто HTML, не внутри <?php ?> -->
      <a href="log.php" class="btn btn-outline-light">Выход</a>
    </div>
  </div>
</nav>


<div class="container mt-4">
  <h4>Здравствуйте, <?php echo $_SESSION['user']['username']; ?>!</h4>

  <div class="mt-4">
   <h5 class="mt-4">📦 Товары на складе</h5>
<table class="table table-bordered">
  <thead>
    <tr>
      <th>Наименование</th>
      <th>Артикул</th>
      <th>Остаток</th>
    </tr>
  </thead>
  <tbody>
    <?php
    require_once 'db.php';
    $result = $conn->query("SELECT name, sku, quantity FROM products ORDER BY name");
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['name']}</td>
                <td>{$row['sku']}</td>
                <td>{$row['quantity']}</td>
              </tr>";
    }
    ?>
  </tbody>
</table>

  </div>

  <div class="mt-4">
    <h5>➕ Добавление поставки</h5>
    <form method="POST" action="add_supply.php">
      <div class="row mb-3">
        <!-- ПРАВИЛЬНО -->
<div class="col">
  <label>Товар</label>
  <select name="product_id" class="form-control" required>
    <?php
      require_once 'db.php';
      $result = $conn->query("SELECT id, name FROM products ORDER BY name");
      while ($row = $result->fetch_assoc()) {
          echo "<option value='{$row['id']}'>{$row['name']}</option>";
      }
    ?>
  </select>
</div>

        </div>
        <div class="col">
          <label>Количество</label>
          <input type="number" name="quantity" class="form-control" required>
        </div>
      </div>
      <button class="btn btn-success">Добавить поставку</button>
    </form>
  </div>

  <div class="mt-4">
    <h5>📑 История поставок</h5>
    <p>Здесь будет таблица с личными поставками (дата, товар, количество).</p>
  </div>
</div>
</body>
</html>
