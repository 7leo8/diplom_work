<?php
$host = "localhost";
$db = "u3137113_default";
$user = "u3137113_default";
$pass = "sMnGg32j5X2iX72v";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}
?>
