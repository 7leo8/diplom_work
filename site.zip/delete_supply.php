<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

$id = intval($_GET['id']);

// Получаем количество и товар, чтобы откатить остаток
$res = $conn->query("SELECT product_id, quantity FROM supplies WHERE id = $id");
if ($res && $res->num_rows === 1) {
    $row = $res->fetch_assoc();
    $conn->query("UPDATE products SET quantity = quantity - {$row['quantity']} WHERE id = {$row['product_id']}");
    $conn->query("DELETE FROM supplies WHERE id = $id");
}

header("Location: supply_history.php");
exit();
