<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

require_once 'db.php';

$id = intval($_GET['id']);
$product = $conn->query("SELECT * FROM products WHERE id = $id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $sku = trim($_POST['sku']);
    $quantity = intval($_POST['quantity']);
    $stmt = $conn->prepare("UPDATE products SET name=?, sku=?, quantity=? WHERE id=?");
    $stmt->bind_param("ssii", $name, $sku, $quantity, $id);
    $stmt->execute();
    header("Location: products.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Редактирование товара</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h3>Редактировать товар</h3>
  <form method="POST" class="mt-3">
    <div class="mb-3">
      <label>Наименование</label>
      <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($product['name']) ?>" required>
    </div>
    <div class="mb-3">
      <label>Артикул</label>
      <input type="text" name="sku" class="form-control" value="<?= htmlspecialchars($product['sku']) ?>" required>
    </div>
    <div class="mb-3">
      <label>Количество</label>
      <input type="number" name="quantity" class="form-control" value="<?= $product['quantity'] ?>" required>
    </div>
    <button class="btn btn-primary">Сохранить</button>
    <a href="products.php" class="btn btn-secondary">Отмена</a>
  </form>
</div>
</body>
</html>
