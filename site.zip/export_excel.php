<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    exit("Доступ запрещён");
}

require_once 'db.php';

// Установка заголовков
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=report_" . date("Y-m-d") . ".xls");
header("Pragma: no-cache");
header("Expires: 0");

$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');

$sql = "SELECT p.name, SUM(s.quantity) as total
        FROM supplies s
        JOIN products p ON s.product_id = p.id
        WHERE s.supply_date BETWEEN '$from' AND '$to'
        GROUP BY s.product_id";

$data = $conn->query($sql);

// Таблица Excel
echo "<table border='1'>";
echo "<tr><th>Товар</th><th>Общее количество</th></tr>";
while ($row = $data->fetch_assoc()) {
    echo "<tr><td>{$row['name']}</td><td>{$row['total']}</td></tr>";
}
echo "</table>";
?>
