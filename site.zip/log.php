<?php
session_start();
session_unset();  // очищаем все переменные сессии
session_destroy(); // уничтожаем сессию
header("Location: index.html"); // перенаправление на форму входа
exit();

?>

