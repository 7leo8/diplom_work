<?php
session_start();
require_once 'db.php'; // подключение к БД

// Получение и фильтрация данных
$username = trim($_POST['username']);
$password = $_POST['password'];

// Проверка: логин в нижнем регистре, пароль — чувствителен
$query = $conn->prepare("SELECT * FROM users WHERE LOWER(username) = LOWER(?)");
$query->bind_param("s", $username);
$query->execute();
$result = $query->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'role' => $user['role']
        ];
        // Перенаправление по ролям
        if ($user['role'] === 'admin') {
            header("Location: dashboard_admin.php");
        } else {
            header("Location: dashboard_staff.php");
        }
        exit();
    }
}

echo "<p style='text-align:center; color:red;'>Неверный логин или пароль.</p>";
echo "<p style='text-align:center;'><a href='login.html'>Вернуться назад</a></p>";
?>
<?php
session_start();
require_once 'login_logic.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = loginUser($_POST['username'], $_POST['password']);

    if ($result === "SUCCESS") {
        header("Location: " . ($_SESSION['user']['role'] === 'admin' ? "dashboard_admin.php" : "dashboard_staff.php"));
        exit();
    } else {
        echo "<div class='alert alert-danger'>$result</div>";
    }
}

