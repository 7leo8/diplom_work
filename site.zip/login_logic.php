<?php
require_once 'db.php';

function loginUser($username, $password) {
    global $conn;

    if (!$conn) return "Ошибка подключения к БД.";

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    if (!$stmt) return "Ошибка подготовки запроса.";

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res && $res->num_rows === 1) {
        $user = $res->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user;
            return "SUCCESS";
        }
    }
    return "Неверный логин или пароль.";
}
