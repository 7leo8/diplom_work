<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}
require_once 'db.php';
$logs = $conn->query("
    SELECT l.action, l.created_at, u.username
    FROM logs l
    JOIN users u ON l.user_id = u.id
    ORDER BY l.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Журнал действий</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h3>🧾 Журнал действий</h3>
  <table class="table table-striped">
    <thead>
      <tr><th>Дата</th><th>Пользователь</th><th>Действие</th></tr>
    </thead>
    <tbody>
      <?php while ($row = $logs->fetch_assoc()): ?>
      <tr>
        <td><?= $row['created_at'] ?></td>
        <td><?= $row['username'] ?></td>
        <td><?= htmlspecialchars($row['action']) ?></td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
  <a href="dashboard_admin.php" class="btn btn-secondary mt-3">← Назад</a>
</div>
</body>
</html>
