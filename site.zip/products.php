<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

require_once 'db.php';

// Добавление товара
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $name = trim($_POST['name']);
    $sku = trim($_POST['sku']);
    $quantity = intval($_POST['quantity']);
    $stmt = $conn->prepare("INSERT INTO products (name, sku, quantity) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $name, $sku, $quantity);
    $stmt->execute();
    header("Location: products.php");
    exit();
}

// Удаление товара
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM products WHERE id = $id");
    header("Location: products.php");
    exit();
}

// Список товаров
$result = $conn->query("SELECT * FROM products ORDER BY name");
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Управление товарами</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h3>📦 Управление товарами</h3>

  <form method="POST" class="row g-3 mb-4">
    <input type="hidden" name="add" value="1">
    <div class="col-md-4">
      <input type="text" name="name" class="form-control" placeholder="Наименование" required>
    </div>
    <div class="col-md-3">
      <input type="text" name="sku" class="form-control" placeholder="Артикул" required>
    </div>
    <div class="col-md-3">
      <input type="number" name="quantity" class="form-control" placeholder="Количество" required>
    </div>
    <div class="col-md-2">
      <button class="btn btn-success w-100">Добавить</button>
    </div>
  </form>

  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Наименование</th>
        <th>Артикул</th>
        <th>Остаток</th>
        <th>Действие</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['name']) ?></td>
          <td><?= htmlspecialchars($row['sku']) ?></td>
          <td><?= $row['quantity'] ?></td>
          <td>
            <a href="edit_product.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Редактировать</a>
            <a href="products.php?delete=<?= $row['id'] ?>" class="btn btn-sm btn-danger"
               onclick="return confirm('Удалить товар?')">Удалить</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>

  <a href="dashboard_admin.php" class="btn btn-secondary mt-3">← Назад</a>
</div>
</body>
</html>
