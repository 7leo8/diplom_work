<?php
require_once 'db.php';

$username = trim($_POST['username']);
$password = $_POST['password'];
$role = $_POST['role'];

// Проверка на допустимые символы
if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
    exit("Недопустимые символы в логине. <a href='register.html'>Назад</a>");
}

// Проверка: логин уже существует?
$stmt = $conn->prepare("SELECT id FROM users WHERE LOWER(username) = LOWER(?)");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    exit("Пользователь с таким логином уже существует. <a href='register.html'>Назад</a>");
}

// Хэширование пароля и добавление в БД
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $username, $hash, $role);

if ($stmt->execute()) {
    echo "Регистрация прошла успешно. <a href='login.html'>Войти</a>";
} else {
    echo "Ошибка при регистрации. <a href='register.html'>Повторить</a>";
}
?>
