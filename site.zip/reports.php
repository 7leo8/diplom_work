<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}
require_once 'db.php';

$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$sql = "SELECT p.name, SUM(s.quantity) as total
        FROM supplies s
        JOIN products p ON s.product_id = p.id
        WHERE s.supply_date BETWEEN '$from' AND '$to'
        GROUP BY s.product_id";

$data = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Отчёты</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h3>📊 Отчёты по поставкам</h3>
  <form class="row mb-4">
    <div class="col"><input type="date" name="from" value="<?= $from ?>" class="form-control"></div>
    <div class="col"><input type="date" name="to" value="<?= $to ?>" class="form-control"></div>
    <div class="col"><button class="btn btn-primary">Фильтр</button></div>
  </form>
  <table class="table table-bordered">
    <thead><tr><th>Товар</th><th>Общее количество</th></tr></thead>
    <tbody>
      <?php while ($row = $data->fetch_assoc()): ?>
      <tr><td><?= $row['name'] ?></td><td><?= $row['total'] ?></td></tr>
      <?php endwhile; ?>
    </tbody>
  </table>
  <div class="mt-5">
  <h5>📉 Диаграмма остатков на складе</h5>
  <canvas id="stockChart" height="100"></canvas>
</div>

<script>
const ctx = document.getElementById('stockChart').getContext('2d');
const stockChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{
            label: 'Остаток (шт)',
            data: <?= json_encode($values) ?>,
            backgroundColor: 'rgba(54, 162, 235, 0.6)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true }
        }
    }
});
</script>

  <a href="export_excel.php?from=<?= $from ?>&to=<?= $to ?>" class="btn btn-success mt-3">📥 Скачать в Excel</a>
<a href="dashboard_admin.php" class="btn btn-secondary mt-3 ms-2">← Назад</a>
</div>
<?php
// Остатки товаров для графика
$chartData = $conn->query("SELECT name, quantity FROM products ORDER BY name");
$labels = [];
$values = [];

while ($row = $chartData->fetch_assoc()) {
    $labels[] = $row['name'];
    $values[] = $row['quantity'];
}
?>
</body>
</html>
