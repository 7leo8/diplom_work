<?php
session_start(); // Всегда в первой строке!
require_once 'login_logic.php'; // Подключаем только логику (без HTML)

$_SESSION = []; // Сброс предыдущих сессий

function test_success_login() {
    $result = loginUser('admin', 'admin123'); // предполагается, что пользователь admin уже есть в БД
    echo $result === 'SUCCESS'
        ? "✅ Успешный вход — PASSED<br>"
        : "❌ Успешный вход — FAILED (Ответ: $result)<br>";
}

test_success_login();
?>
