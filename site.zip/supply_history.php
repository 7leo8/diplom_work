<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user']['id'];
$is_admin = $_SESSION['user']['role'] === 'admin';

// SQL-запрос: если админ — все записи, иначе — только свои
$sql = $is_admin
    ? "SELECT s.id, p.name AS product, s.quantity, s.supply_date, u.username
       FROM supplies s
       JOIN products p ON s.product_id = p.id
       JOIN users u ON s.user_id = u.id
       ORDER BY s.supply_date DESC"
    : "SELECT s.id, p.name AS product, s.quantity, s.supply_date
       FROM supplies s
       JOIN products p ON s.product_id = p.id
       WHERE s.user_id = $user_id
       ORDER BY s.supply_date DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>История поставок</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h3 class="mb-4">📑 История поставок</h3>

  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>Дата</th>
        <th>Товар</th>
        <th>Количество</th>
        <?php if ($is_admin): ?>
        <th>Пользователь</th>
        <th>Действие</th>
        <?php endif; ?>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= $row['supply_date'] ?></td>
          <td><?= $row['product'] ?></td>
          <td><?= $row['quantity'] ?></td>
          <?php if ($is_admin): ?>
          <td><?= $row['username'] ?></td>
          <td>
            <a href="delete_supply.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger"
               onclick="return confirm('Удалить поставку?')">Удалить</a>
          </td>
          <?php endif; ?>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>

  <a href="<?= $is_admin ? 'dashboard_admin.php' : 'dashboard_staff.php' ?>" class="btn btn-secondary mt-3">← Назад</a>
</div>
</body>
</html>
