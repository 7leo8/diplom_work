<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}
require_once 'db.php';

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM users WHERE id = $id AND id != {$_SESSION['user']['id']}");
    header("Location: users.php");
    exit();
}

$users = $conn->query("SELECT id, username, role FROM users ORDER BY role");
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Пользователи</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h3>👥 Пользователи</h3>
  <table class="table table-bordered">
    <thead><tr><th>Имя</th><th>Роль</th><th>Действие</th></tr></thead>
    <tbody>
      <?php while ($u = $users->fetch_assoc()): ?>
      <tr>
        <td><?= $u['username'] ?></td>
        <td><?= $u['role'] ?></td>
        <td>
          <?php if ($u['id'] != $_SESSION['user']['id']): ?>
          <a href="?delete=<?= $u['id'] ?>" class="btn btn-sm btn-danger"
             onclick="return confirm('Удалить пользователя?')">Удалить</a>
          <?php else: ?>
          <em>Вы</em>
          <?php endif; ?>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
  <a href="dashboard_admin.php" class="btn btn-secondary">← Назад</a>
</div>
</body>
</html>
